import java.util.*;
import java.io.*;
import java.net.*;
public class TCPServer implements ProcessListener
{
private HashMap<Integer,Pair<int,int>> socketHashMap=new HashMap<>();
private HashMap<String,Processor> processors=new HashMap<>();
private int portNumber1,portNumber2;
private ServerSocket serverSocket1,serverSocket2;
private TCPListener tcpListener;
public TCPServer(int portNumber1,int portNumber2)
{
this.portNumber1=portNumber1;
this.portNumber2=portNumber2;
this.serverSocket1=null;
this.serverSocket2=null;
}

public void start(TCPListener tcpListener) throws IOException
{
this.tcpListener=tcpListener;
serverSocket1=new ServerSocket(portNumber1);
serverSocket2=new ServerSocket(portNumber2);
this.startAcception();
}

public void startAccepting() throws IOException
{
Socket socket1,socket2;
Processor processor;
String processorId;
while(true)
{
processorId=UUID.randomUUID().toString();
socket1=serverSocket1.accept();
processor=new Processor(socket1,this,tcpListener,processorId)
processors.put(processorId,processor);
processor.start();
}
}

public void onCompleted(Processor processor)
{
processors.remove(processor.getId());
}

}