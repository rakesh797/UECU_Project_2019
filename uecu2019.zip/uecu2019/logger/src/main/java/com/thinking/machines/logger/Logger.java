package com.thinking.machines.logger;
import java.io.*;
import java.util.*;
import java.text.*;
public class Logger
{
public static String prefix;
public static String suffix;
public static String remoteAddress;
public static String requestString;
public static String requestTimeString;
public static String responseString;
public static String responseTimeString;
public static boolean setStore;
public static boolean debugMode;
public static void log(java.util.Date date,String log)
{
try
{
File file=new File("abcd.txt");
RandomAccessFile randomAccessFile=new RandomAccessFile(file,"rw");
if(!file.exists())
{
file.createNewFile();
}
randomAccessFile.seek(file.length());

String json="{"+"IPAddress:"+remoteAddress+","+"Date:"+date+","+"Time:"+requestTimeString+","+"Request:"+requestString+"}"+"\n";
//
randomAccessFile.writeBytes(json);
randomAccessFile.close();
}catch(Throwable throwable)
{
throwable.printStackTrace();
}
}
public static void setStore(boolean setStore)
{
setStore=setStore;
}
public static void setDebugMode(boolean debugMode)
{
debugMode=debugMode;
}
public static void setPrefix(String pre)
{
prefix=pre;
}
public static void setSuffix(String suff)
{
suffix=suff;
}
public static void main(String gg[])
{
Logger.setPrefix("chat");
Logger.setSuffix("log");
SimpleDateFormat sdtf=new SimpleDateFormat("DD/MM/yyyy");
java.util.Date now=new java.util.Date();
Logger.log(now,"flaksdjf;");
}
}