import java.net.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.io.*;
import java.awt.*;
class Student
{
private String name;
private String gender;
private int age;
public void setName(String name)
{
this.name=name;
}
public String getName()
{
return this.name;
}
public void setGender(String gender)
{
this.gender=gender;
}
public String getGender()
{
return gender;
}
public void setAge(int age)
{
this.age=age;
}
public int getAge()
{
return this.age;
}
}
class StudentFrame extends JFrame implements ActionListener
{
private JTextField t1,t2,t3;
private JLabel l1,l2,l3;
private JButton b;
private ChotaClient chotaClient;
StudentFrame(ChotaClient chotaClient)
{
this.chotaClient=chotaClient;
//this.chotaClient=new ChotaClient();
t1=new JTextField();
t2=new JTextField();
t3=new JTextField();
l1=new JLabel("Name:-");
l2=new JLabel("Gender:-");
l3=new JLabel("Age:-");
b=new JButton("send");
b.addActionListener(this);
setLayout(new GridLayout(4,2));
add(l1);
add(t1);
add(l2);
add(t2);
add(l3);
add(t3);
add(b);
add(new JLabel());
setLocation(100,100);
setSize(300,300);
setVisible(true);
}
public void actionPerformed(ActionEvent ae)
{
if(ae.getSource()==b)
{
Student student=new Student();
student.setName(t1.getText());
student.setGender(t2.getText());
student.setAge(Integer.parseInt(t3.getText()));
String request=student.getName()+","+student.getGender()+","+student.getAge()+"#";
System.out.println(chotaClient);
String response=chotaClient.send(request);
System.out.println(response);
}
}
}

class ChotaClient
{
private Socket socket;
public ChotaClient(Socket s)
{
socket=s;
}
public String send(String request)
{
String serverName="localhost";
int portNumber=5000;
try
{
System.out.println("try me");
//Socket socket=new Socket(serverName,portNumber);
OutputStream os;
OutputStreamWriter osw;
InputStream is;
InputStreamReader isr;
StringBuffer sb;
String response;
int x;
os=socket.getOutputStream();
osw=new OutputStreamWriter(os);
osw.write(request);
osw.flush(); //request sent
System.out.println("SEnt");
is=socket.getInputStream();
isr=new InputStreamReader(is);
sb=new StringBuffer();
while(true)
{
x=isr.read();
if(x=='#' || x==-1)
{
break;
}
sb.append((char)x);
}
response=sb.toString();
System.out.println(response);
//socket.close();
return response;
}catch(Exception e)
{
System.out.println(e);
}
return null;
}
}

class ChotaServer
{
private ServerSocket serverSocket;
private int portNumber;
ChotaServer(int portNumber)
{
this.portNumber=portNumber;
try
{
serverSocket=new ServerSocket(this.portNumber);
startListening();
}catch(Exception e)
{
System.out.println(e);
System.exit(0);
}
}
public void startListening()
{
try
{
Socket ck;
while(true)
{
System.out.println("Server is listening on port : "+this.portNumber);
ck=serverSocket.accept();
System.out.println("Request arrived");
new RequestProcessor(ck);
}
}catch(Exception e)
{
System.out.println(e);
}
}
public static void main(String data[])
{
int portNumber=Integer.parseInt(data[0]);
ChotaServer cs=new ChotaServer(portNumber);
}
}
class RequestProcessor extends Thread
{
private Socket ck;
RequestProcessor(Socket socket)
{
this.ck=socket;
start();
}
public void run()
{
try
{
InputStream is;
InputStreamReader isr;
OutputStream os;
OutputStreamWriter osw;
StringBuffer sb;
String request;
int x;
int c1,c2;
String p1,p2,pc3;
int rollNumber;
String name;
String gender;
String response;
is=ck.getInputStream();
isr=new InputStreamReader(is);
sb=new StringBuffer();
while(true)
{
x=isr.read();
if(x=='#' || x==-1)
{
break;
}
sb.append((char)x);
}
request=sb.toString();
System.out.println("Request :"+request);

//Code to save data
response="Data saved#";
os=ck.getOutputStream();
osw=new OutputStreamWriter(os);
osw.write(response);
osw.flush();
System.out.println("Response sent");
ck.close();
}catch(Exception e)
{
System.out.println(e);
}
}
}
class psp
{
public static void main(String gg[]) throws IOException
{
Socket s=new Socket("localhost",5000);
ChotaClient chotaClient=new ChotaClient(s);
StudentFrame sf=new StudentFrame(chotaClient);
}
}