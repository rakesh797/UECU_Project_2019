package com.thinking.machines.tcp.client;
public interface ResponseListener
{
public void onResponse(byte bytes[]);
//public void onError(TCPNetworkError tcpNetworkError);
}