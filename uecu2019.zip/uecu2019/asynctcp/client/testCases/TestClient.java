import com.thinking.machines.tcp.client.*;
import java.io.*;
public class TestClient
{
public static void main(String gg[]) throws IOException
{
TCPClient tcpClient=new TCPClient(5000,"localhost");
System.out.println(new String(tcpClient.send(gg[0].getBytes())));
}
}