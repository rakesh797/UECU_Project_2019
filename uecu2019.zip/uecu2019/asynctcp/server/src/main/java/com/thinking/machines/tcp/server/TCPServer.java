package com.thinking.machines.tcp.server;
import com.thinking.machines.tcp.server.event.*;
import com.thinking.machines.tcp.server.pojo.*;
import java.util.*;
import java.io.*;
import java.net.*;
public class TCPServer implements ProcessListener
{
private HashMap<String,Processor> processors=new HashMap<>();
private ServerSocket serverSocket;
private int portNumber;
private TCPListener tcpListener;
public TCPServer(int portNumber)
{
this.portNumber=portNumber;
this.serverSocket=null;
}
public void start(TCPListener tcpListener) throws IOException
{
this.tcpListener=tcpListener;
serverSocket=new ServerSocket(portNumber);
this.startAccepting();
}
public void startAccepting() throws IOException
{
Socket socket;
Processor processor;
String processorId;
while(true)
{
processorId=UUID.randomUUID().toString();
socket=serverSocket.accept();
processor=new Processor(socket,this,tcpListener,processorId);
processors.put(processorId,processor);
processor.start();
}
}
public void onCompleted(Processor processor)
{
processors.remove(processor.getId());
}
}