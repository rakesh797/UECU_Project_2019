package com.thinking.machines.tcp.server.pojo;
public class Packet
{
private String clientIP;
private byte[] bytes;
public void setClientIP(String clientIP)
{
this.clientIP=clientIP;
}
public String getClientIP()
{
return this.clientIP;
}
public void setBytes(byte[] bytes)
{
this.bytes=bytes;
}
public byte[] getBytes()
{
return this.bytes;
}
}