import com.thinking.machines.chat.server.*;
import com.thinking.machines.tcp.server.event.*;
import com.thinking.machines.tcp.server.*;
import com.thinking.machines.tcp.server.pojo.*;
import java.util.*;
import java.io.*;
class TestTCPHandler implements TCPListener
{
public byte[] onBytesReceived(Packet packet) 
{
System.out.println("request received from :"+packet.getClientIP());
String request=new String(packet.getBytes());
try
{
System.out.println("client :"+request);
String messageResponse=MessageProcessor.process(request,packet.getClientIP(),5000);
return messageResponse.getBytes();
}catch(Exception exception)
{
System.out.println(exception);
}
return null;
}
}
class TestServer
{
public static void main(String gg[]) throws IOException
{
TCPServer tcpServer=new TCPServer(5000);
tcpServer.start(new TestTCPHandler());
}
}