package com.thinking.machines.rest.pojo;
public class Guard
{

}