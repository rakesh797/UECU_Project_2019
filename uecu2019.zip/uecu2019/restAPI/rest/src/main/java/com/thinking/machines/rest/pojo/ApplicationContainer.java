package com.thinking.machines.rest.pojo;
import javax.servlet.*;
import java.util.*;
public class ApplicationContainer implements java.io.Serializable
{
private ServletContext servletContext;
ApplicationContainer(ServletContext servletContext)
{
this.servletContext=servletContext;
}
public void setAttribute(String name,Object value)
{
this.servletContext.setAttribute(name,value);
}
public Object getAttribute(String name)
{
return this.servletContext.getAttribute(name);
}
public void removeAttribute(String name)
{
this.servletContext.removeAttribute(name);
}
public void removeAllAttributes()
{
Enumeration<String> e=servletContext.getAttributeNames();
while(e.hasMoreElements())
{
servletContext.removeAttribute(e.nextElement());
}
}
}