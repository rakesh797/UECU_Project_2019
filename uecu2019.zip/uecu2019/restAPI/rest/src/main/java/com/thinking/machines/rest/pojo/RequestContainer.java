package com.thinking.machines.rest.pojo;
import javax.servlet.http.*;
import java.util.*;
public class RequestContainer implements java.io.Serializable
{
private HttpServletRequest httpServletRequest;
RequestContainer(HttpServletRequest httpServletRequest)
{
this.httpServletRequest=httpServletRequest;
}
public void setAttribute(String name,Object value)
{
this.httpServletRequest.setAttribute(name,value);
}
public Object getAttribute(String name)
{
return this.httpServletRequest.getAttribute(name);
}
public void removeAttribute(String name)
{
this.httpServletRequest.removeAttribute(name);
}
public void removeAllAttribute()
{
Enumeration<String> e=httpServletRequest.getAttributeNames();
while(e.hasMoreElements())
{
httpServletRequest.removeAttribute(e.nextElement());
}
}
}