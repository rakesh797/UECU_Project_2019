package com.thinking.machines.rest.annotation;
import com.thinking.machines.rest.enums.*;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface Produces
{
ResponseType value() default ResponseType.JSON;
}