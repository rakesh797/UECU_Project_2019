package com.thinking.machines.rest.pojo;
import javax.servlet.*;
import javax.servlet.http.*;
public class CookieManager
{
public HttpServletRequest request;
public CookieManager(HttpServletRequest request)
{
this.request=request;
}
}