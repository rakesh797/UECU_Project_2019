package com.thinking.machines.rest.interfaces;
public interface ServiceController
{
default public void init()
{

}
}