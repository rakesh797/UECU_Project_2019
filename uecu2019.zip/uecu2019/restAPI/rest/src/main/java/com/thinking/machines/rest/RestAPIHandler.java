/*
package com.thinking.machines.rest;
public class RestAPIHandler
{
public void something(Some some...)
{
String path=request.getPathInfo();
ServletContext servletContext=getServletContext();
DataModel dataModel=(DataModel)servletContext.getAttribute(DataModel.Id);
ServiceModule serviceModule=dataModel.getServiceModule(path);
if(serviceModule==null)
{
response.sendError(HttpServletResponse.SC_NOT_FOUND);
return;
}
Service service=serviceModule.getService(path);
String requestMethodType=request.getMethodType();
if(requestMethodType.equalsIgnoreCase("GET"))
{
if(!service.allowGet())
{
response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
return;
}
}
Object serviceObject=serviceModule.getServiceObject(servletContext,request,service);
if(serviceModule.isSecured() || service.isSecured())
{
// some code
}
Object arguments[]=service.getArguments(servletContext,request);
try{
Method method=service.getMethod();
Object result=method.invoke(serviceObject,arguments);
if(service.isForwarding())
{
RequestDispatcher requestDipatcher=request.getRequestDispatcher();
}

}catch(InvocationTargetException | ClassNotFoundException | NoSuchMethodException | IllegalAccessException exception)
{
exception.getCause();
}
}
}
*/