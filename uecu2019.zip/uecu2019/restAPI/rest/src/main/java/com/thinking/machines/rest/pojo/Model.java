package com.thinking.machines.rest.pojo;
import java.util.*;
import java.io.*;
public class Model
{
public final static String id;
private ContextDirectory contextDirectory;
static
{
id=java.util.UUID.randomUUID().toString();
}
private Map<String,String> serviceModuleKeys;
private Map<String,ServiceModule> serviceModules;
public Model()
{
serviceModuleKeys=new HashMap<>();
serviceModules=new HashMap<>();
}
public void addServiceModule(ServiceModule serviceModule)
{
String path=serviceModule.getPath();
String serviceModuleKey=UUID.randomUUID().toString();
serviceModules.put(serviceModuleKey,serviceModule);
Map<String,Service> services=serviceModule.getServices();
Set<String> serviceKeys=services.keySet();
String servicePath;
for(String key:serviceKeys)
{
servicePath=path+key;
serviceModuleKeys.put(servicePath,serviceModuleKey);
}
}
public ServiceModule getServiceModule(String requestPath)
{
String serviceModuleKey=serviceModuleKeys.get(requestPath);
if(serviceModuleKey==null) return null;
ServiceModule serviceModule=serviceModules.get(serviceModuleKey);
return serviceModule;
}
public void setContextDirectory(String folder)
{
this.contextDirectory= new ContextDirectory(new File(folder));
}
public ContextDirectory getContextDirectory()
{
return contextDirectory;
}
}