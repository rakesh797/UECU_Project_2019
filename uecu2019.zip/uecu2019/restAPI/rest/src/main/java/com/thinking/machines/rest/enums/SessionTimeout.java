package com.thinking.machines.rest.enums;
public enum SessionTimeout
{
SECONDS,
MINUTES,
HOURS
}