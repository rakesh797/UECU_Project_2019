package com.thinking.machines.rest.pojo;
import java.lang.reflect.*;
public class AutowiredField
{
private String name;
private Field field;
public AutowiredField()
{
this.field=null;
this.name="";
}
public void setName(String name)
{
this.name=name;
}
public String getName()
{
return this.name;
}
public void setField(Field field)
{
this.field=field;
}
public Field getField()
{
return this.field;
}
}