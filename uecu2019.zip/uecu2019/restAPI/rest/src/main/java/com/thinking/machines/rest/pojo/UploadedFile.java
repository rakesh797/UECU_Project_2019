package com.thinking.machines.rest.pojo;
import java.io.*;
public class UploadedFile implements java.io.Serializable
{
private File file;
private boolean removeLater;
public void setFile(File file)
{
this.file=file;
}
public void setRemoveLater(boolean removeLater)
{
this.removeLater=removeLater;
}
public File getFile()
{
return this.file;
}
public boolean getRemoveLater()
{
return this.removeLater;
}
}