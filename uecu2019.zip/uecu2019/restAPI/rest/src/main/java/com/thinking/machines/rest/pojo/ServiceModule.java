package com.thinking.machines.rest.pojo;
import java.lang.reflect.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.thinking.machines.rest.interfaces.*;
import com.thinking.machines.rest.pools.*;
import com.thinking.machines.rest.annotations.*;
public class ServiceModule implements java.io.Serializable
{
private String path;
private Class serviceClass;
private Method applicationInjectorMethod;
private Method sessionInjectorMethod;
private Method requestInjectorMethod;
private Method cookieManagerInjectorMethod;
private Method contextDirectoryInjectorMethod;
private Field applicationContainerField;
private Field sessionContainerField;
private Field requestContainerField;
private Field cookieManagerField;
private Field contextDirectoryField;
private boolean allowGet;
private boolean allowPost;
private boolean isSecured;
private Guard guard;
private Map<String,Service> services;
private List<AutowiredField> autowiredFields;
public void setPath(String path)
{
this.path=path;
}
public String getPath()
{
return this.path;
}
public void setServices(Map<String,Service> services)
{
this.services=services;
}
public Map<String,Service> getServices()
{
return this.services;
}
// *****This will produce the Object of the Class in which the given service resides*****
public Object getServiceObject(ServletContext servletContext,HttpServletRequest request,Service service) throws Throwable
{
Model model=(Model)servletContext.getAttribute(Model.id);
ServiceController serviceObject;
serviceObject=ServiceObjectPool.get(this.serviceClass);

if(applicationInjectorMethod!=null) applicationInjectorMethod.invoke(serviceObject,new ApplicationContainer(servletContext));
else if(applicationContainerField!=null) applicationContainerField.set(serviceObject,new ApplicationContainer(servletContext));

if(sessionInjectorMethod!=null) sessionInjectorMethod.invoke(serviceObject,new SessionContainer(request.getSession()));
else if(sessionContainerField!=null) sessionContainerField.set(serviceObject,new SessionContainer(request.getSession()));

if(requestInjectorMethod!=null) requestInjectorMethod.invoke(serviceObject,new RequestContainer(request));
else if(requestContainerField!=null) requestContainerField.set(serviceObject,new RequestContainer(request));

if(cookieManagerInjectorMethod!=null) cookieManagerInjectorMethod.invoke(serviceObject,new CookieManager(request));
else if(cookieManagerField!=null) cookieManagerField.set(serviceObject,new CookieManager(request));

//if(contextDirectoryInjectorMethod!=null) contextDirectoryInjectorMethod.invoke(serviceObject,model.getContextDirectory());
//else if(contextDirectoryField!=null) contextDirectoryField.set(serviceObject,model.getContextDirectory());

for(AutowiredField awf:autowiredFields)
{
String name=awf.getName();
Field field=awf.getField();
Object object=null;
if(name.length()>0)
{
String paramValues[]=request.getParameterValues(name);
if(paramValues!=null) object=parseParamValues(paramValues,field.getType());
if(object==null) object=request.getAttribute(name);
if(object==null) object=request.getSession().getAttribute(name);
if(object==null) object=servletContext.getAttribute(name);
}
else
{

/*
if field represents a string then extract the first string type
from parameter and assign if to object variable
*/

if(object==null)
{
Enumeration en=request.getAttributeNames();
while(en.hasMoreElements())
{
Object value=request.getAttribute((String)en.nextElement());
if(field.getType().isInstance(value));
{
object=value;
break;
}
}
}

if(object==null)
{
HttpSession session=request.getSession();
Enumeration en=session.getAttributeNames();
while(en.hasMoreElements())
{
Object value=session.getAttribute((String)en.nextElement());
if(field.getType().isInstance(value))
{
object=value;
break;
}
}
}

if(object==null)
{
Enumeration en=servletContext.getAttributeNames();
while(en.hasMoreElements())
{
Object value=servletContext.getAttribute((String)en.nextElement());
if(field.getType().isInstance(value))
{
object=value;
break;
}
}
}
}
field.set(serviceObject,object);
} // for loop on AutoWiredField ends here.
return serviceObject;
}

public Object parseParamValues(String []values,Class type)
{
try
{
if(values==null || values.length==0) return null;
if(type.isArray()==false)
{
String data=values[0];
return parseParamValue(data,type);
}
if(type.getComponentType().isArray()) return null;
if(type.equals(String[].class)) return values;

if(type.equals(Long[].class))
{
Long[] ll=new Long[values.length];
int i=0;
int correct=0;
for(String s:values)
{
try{
ll[i]=Long.parseLong(s);
correct++;
i++;
}catch(NumberFormatException nfe){}
}
Long lll[]=new Long[correct];
for(i=0;i<correct;i++) lll[i]=ll[i];
return lll;
}

if(type.equals(long[].class))
{
long[] ll=new long[values.length];
int i=0;
int correct=0;
for(String s:values)
{
try{
ll[i]=Long.parseLong(s);
correct++;
i++;
}catch(NumberFormatException nfe){}
}
long lll[]=new long[correct];
for(i=0;i<correct;i++) lll[i]=ll[i];
return lll;
}

if(type.equals(Integer[].class))
{
Integer[] ll=new Integer[values.length];
int i=0;
int correct=0;
for(String s:values)
{
try{
ll[i]=Integer.parseInt(s);
correct++;
i++;
}catch(NumberFormatException nfe){}
}
Integer lll[]=new Integer[correct];
for(i=0;i<correct;i++) lll[i]=ll[i];
return lll;
}

if(type.equals(int[].class))
{
int[] ll=new int[values.length];
int i=0;
int correct=0;
for(String s:values)
{
try{
ll[i]=Integer.parseInt(s);
correct++;
i++;
}catch(NumberFormatException nfe){}
}
int lll[]=new int[correct];
for(i=0;i<correct;i++) lll[i]=ll[i];
return lll;
}

if(type.equals(Short[].class))
{
Short[] ll=new Short[values.length];
int i=0;
int correct=0;
for(String s:values)
{
try{
ll[i]=Short.parseShort(s);
correct++;
i++;
}catch(NumberFormatException nfe){}
}
Short lll[]=new Short[correct];
for(i=0;i<correct;i++) lll[i]=ll[i];
return lll;
}

if(type.equals(short[].class))
{
short[] ll=new short[values.length];
int i=0;
int correct=0;
for(String s:values)
{
try{
ll[i]=Short.parseShort(s);
correct++;
i++;
}catch(NumberFormatException nfe){}
}
short lll[]=new short[correct];
for(i=0;i<correct;i++) lll[i]=ll[i];
return lll;
}

if(type.equals(Byte[].class))
{
Byte[] ll=new Byte[values.length];
int i=0;
int correct=0;
for(String s:values)
{
try{
ll[i]=Byte.parseByte(s);
correct++;
i++;
}catch(NumberFormatException nfe){}
}
Byte lll[]=new Byte[correct];
for(i=0;i<correct;i++) lll[i]=ll[i];
return lll;
}

if(type.equals(byte[].class))
{
byte[] ll=new byte[values.length];
int i=0;
int correct=0;
for(String s:values)
{
try{
ll[i]=Byte.parseByte(s);
correct++;
i++;
}catch(NumberFormatException nfe){}
}
byte lll[]=new byte[correct];
for(i=0;i<correct;i++) lll[i]=ll[i];
return lll;
}

if(type.equals(Double[].class))
{
Double[] ll=new Double[values.length];
int i=0;
int correct=0;
for(String s:values)
{
try{
ll[i]=Double.parseDouble(s);
correct++;
i++;
}catch(NumberFormatException nfe){}
}
Double lll[]=new Double[correct];
for(i=0;i<correct;i++) lll[i]=ll[i];
return lll;
}

if(type.equals(double[].class))
{
double[] ll=new double[values.length];
int i=0;
int correct=0;
for(String s:values)
{
try{
ll[i]=Double.parseDouble(s);
correct++;
i++;
}catch(NumberFormatException nfe){}
}
double lll[]=new double[correct];
for(i=0;i<correct;i++) lll[i]=ll[i];
return lll;
}

if(type.equals(Float[].class))
{
Float[] ll=new Float[values.length];
int i=0;
int correct=0;
for(String s:values)
{
try{
ll[i]=Float.parseFloat(s);
correct++;
i++;
}catch(NumberFormatException nfe){}
}
Float lll[]=new Float[correct];
for(i=0;i<correct;i++) lll[i]=ll[i];
return lll;
}

if(type.equals(float[].class))
{
float[] ll=new float[values.length];
int i=0;
int correct=0;
for(String s:values)
{
try{
ll[i]=Float.parseFloat(s);
correct++;
i++;
}catch(NumberFormatException nfe){}
}
float lll[]=new float[correct];
for(i=0;i<correct;i++) lll[i]=ll[i];
return lll;
}

if(type.equals(Boolean[].class))
{
Boolean[] ll=new Boolean[values.length];
int i=0;
int correct=0;
for(String s:values)
{
try{
ll[i]=Boolean.parseBoolean(s);
correct++;
i++;
}catch(NumberFormatException nfe){}
}
Boolean lll[]=new Boolean[correct];
for(i=0;i<correct;i++) lll[i]=ll[i];
return lll;
}

if(type.equals(boolean[].class))
{
boolean[] ll=new boolean[values.length];
int i=0;
int correct=0;
for(String s:values)
{
try{
ll[i]=Boolean.parseBoolean(s);
correct++;
i++;
}catch(NumberFormatException nfe){}
}
boolean lll[]=new boolean[correct];
for(i=0;i<correct;i++) lll[i]=ll[i];
return lll;
}

if(type.equals(Character[].class))
{
Character[] cc=new Character[values.length];
int i=0;
int correct=0;
for(String s:values)
{
if(s!=null || s.length()>0)
{
cc[i]=s.charAt(0);
i++;
}
}
return cc;
}

if(type.equals(char[].class))
{
char[] cc=new char[values.length];
int i=0;
int correct=0;
for(String s:values)
{
if(s!=null || s.length()>0)
{
cc[i]=s.charAt(0);
i++;
}
}
return cc;
}
   
/*   
     Character
*/
}catch(NumberFormatException nef){}
return null;
}
private Object parseParamValue(String data,Class type)
{
try
{
if(type.equals(Object.class)) return data;
if(type.equals(String.class)) return data;

if(type.equals(Long.class) || type.equals(long.class)) 
{
try
{
return Long.parseLong(data);
}catch(NumberFormatException nfe)
{
return Long.parseLong("0");
}
}

if(type.equals(Integer.class) || type.equals(int.class)) 
{
try
{
return Integer.parseInt(data);
}catch(NumberFormatException nfe)
{
return Integer.parseInt("0");
}
}

if(type.equals(Short.class) || type.equals(short.class)) 
{
try
{
return Short.parseShort(data);
}catch(NumberFormatException nfe)
{
return Short.parseShort("0");
}
}

if(type.equals(Byte.class) || type.equals(Byte.class)) 
{
try
{
return Byte.parseByte(data);
}catch(NumberFormatException nfe)
{
return Byte.parseByte("0");
}
}

if(type.equals(Double.class) || type.equals(double.class)) 
{
try
{
return Double.parseDouble(data);
}catch(NumberFormatException nfe)
{
return Double.parseDouble("0");
}
}
if(type.equals(Float.class) || type.equals(float.class)) 
{
try
{
return Float.parseFloat(data);
}catch(NumberFormatException nfe)
{
return Float.parseFloat("0");
}
}

if(type.equals(Boolean.class) || type.equals(boolean.class)) 
{
try
{
return Boolean.parseBoolean(data);
}catch(NumberFormatException nfe)
{
return Boolean.parseBoolean("0");
}
}

if(type.equals(Character.class) || type.equals(char.class)) 
{
try
{
return data.charAt(0);
}catch(NumberFormatException nfe)
{
return "\0".charAt(0);
}
}

}catch(Exception e)
{
}
return null;
}
}