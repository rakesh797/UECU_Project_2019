package com.thinking.machines.rest.annotation;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface FileConfiguration
{
public String maximumSize() default "2MB";
public String inputType() default "";
public String extentions() default "{*}";

}