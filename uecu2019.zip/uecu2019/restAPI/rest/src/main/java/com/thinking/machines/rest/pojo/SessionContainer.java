package com.thinking.machines.rest.pojo;
import com.thinking.machines.rest.enums.*;
import javax.servlet.http.*;
import java.util.*;
public class SessionContainer implements java.io.Serializable
{
private HttpSession httpSession;
SessionContainer(HttpSession httpSession)
{
this.httpSession=httpSession;
}
public void setAttribute(String name,Object value)
{
this.httpSession.setAttribute(name,value);
}
public Object getAttribute(String name)
{
return this.httpSession.getAttribute(name);
}
public void removeAttribute(String name)
{
this.httpSession.removeAttribute(name);
}
public void removeAllAttribute()
{
Enumeration<String> e=httpSession.getAttributeNames();
while(e.hasMoreElements())
{
httpSession.removeAttribute(e.nextElement());
}
}
public void end()
{
httpSession.invalidate();
}
public String getId()
{
return httpSession.getId();
}
public void setSessionTimeout(int time,SessionTimeout sessionTimeout)
{
if(sessionTimeout==SessionTimeout.SECONDS)
{
httpSession.setMaxInactiveInterval(time);
}
if(sessionTimeout==SessionTimeout.MINUTES)
{
httpSession.setMaxInactiveInterval(time*60);
}
if(sessionTimeout==SessionTimeout.HOURS)
{
httpSession.setMaxInactiveInterval(time*60*60);
}
}
}