package com.thinking.machines.rest.pojo;
import java.io.*;
public class ContextDirectory
{
private File folder;
public ContextDirectory(File folder)
{
this.folder=folder;
}
}