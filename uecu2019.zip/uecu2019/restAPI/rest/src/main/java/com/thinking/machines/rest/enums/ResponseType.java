package com.thinking.machines.rest.enums;
public enum ResponseType
{
JSON,
NONE,
HTML,
XML,
CSV,
FILE;
}