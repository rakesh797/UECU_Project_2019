package com.thinking.machines.rest.annotations;
import java.lang.annotation.*;
import com.thinking.machines.rest.pojo.*;
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE,ElementType.METHOD})
public @interface Secured
{
public Class guard() default void.class;
//working properly
//public Class guard() default DEFAULT.class;
//static final class DEFAULT{}
}