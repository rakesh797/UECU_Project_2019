import java.lang.*;
class pp
{
public void check(String []abc)
{
System.out.println("falskdj");
}
public static void main(String gg[])
{
check({"abc","pqr"});
}
}
