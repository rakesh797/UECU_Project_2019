import java.lang.reflect.*;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@interface methodTestAnnotation
{
public String name() default "";
}
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@interface classTestAnnotation
{

}

@classTestAnnotation
class Person
{
private String firstName;
private String lastName;
private int age;
public Person(String firstName,String lastName,int age)
{
this.firstName=firstName;
this.lastName=lastName;
this.age=age;
}
@methodTestAnnotation
public void diplay()
{
System.out.println("Name :"+this.firstName+" "+this.lastName+", Age : "+this.age);
}
@methodTestAnnotation
void optionTest(String value) 
{
System.out.println("This is: " + value);
}
public static void main(String gg[])
{
Class<Person> obj=Person.class;
Method []methods=obj.getMethods();
for(Method method:methods)
{
if(method.isAnnotationPresent(methodTestAnnotation.class))
{
System.out.println(method.invoke(obj));
}
}
}
}
