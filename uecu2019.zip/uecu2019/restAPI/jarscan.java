import com.thinking.machines.loadit.*;
import java.lang.reflect.*;
import java.util.jar.*;
import java.util.*;
import java.net.*;
import java.lang.annotation.*;
class psp
{
public static void main(String gg[])
{
String jarFilePath=gg[0];
String className=gg[1];
String methodName=gg[2];
try
{
JarFile jarFile=new JarFile(jarFilePath);
Enumeration<JarEntry> entries=jarFile.entries();
URL urls[]={new URL("jar:file:"+jarFilePath+"!/")};
URLClassLoader urlClassLoader=URLClassLoader.newInstance(urls);
JarEntry jarEntry;
String className2;
String entryName;
Class cls;
while(entries.hasMoreElements())
{
jarEntry=entries.nextElement();
entryName=jarEntry.getName();
if(jarEntry.isDirectory() || !entryName.endsWith(".class")) continue;
className2=entryName.substring(0,entryName.length()-6);
className2=className2.replace('/','.');
System.out.println(className2+" and "+className);
if(className2.equals(className))
{
cls=urlClassLoader.loadClass(className);
System.out.println("Check1");
//Method m=cls.getDeclaredMethod(methodName);
//System.out.println(m.invoke(cls.newInstance()));
Annotation annotations[]=cls.getAnnotations();
for(Annotation a:annotations)
{
System.out.println("Check1.2");

if(a instanceof fs.annotation.Command)
{
System.out.println(((fs.annotation.Command)a).name());
}
}
System.out.println("Check2");

}
}
}catch(Exception exception)
{
//System.out.println(exception.getMessage());
exception.printStackTrace();
}
}
}
-------------------------------------------------------------------------------------------
directory iteration
-------------------------------------------------------------------------------------------
import java.lang.reflect.*;
import java.nio.file.*;
import java.io.*;
class eg1psp
{
public static void main(String gg[])
{
String rootFolder="c:\\123\\TestFolder\\directoryIteration\\classes\\";
try
{
Files.walk(Paths.get(rootFolder)).forEach(path->{
File file=path.toFile();
String pathString=path.toString();
if(file.isFile() && file.getName().endsWith(".class"))
{
pathString=pathString.substring(rootFolder.length(),pathString.length()-6);
pathString=pathString.replace("\\",".");
System.out.println(pathString);
try
{
Class cls=Class.forName(pathString);
}
catch(NoClassDefFoundError ncdfe)
{
System.out.println(ncdfe);
}
catch(Exception e)
{
System.out.println(e);
}

}
});
}catch(Exception exception)
{
System.out.println(exception);
}
}
}