package com.thinking.machines.tcp.common.pojo;
public class Client
{
private String clientIP;
private String clientId;
private byte[] bytes;
public void setClientIP(String clientIP)
{
this.clientIP=clientIP;
}
public String getClientIP()
{
return this.clientIP;
}
public void setClientId(String clientId)
{
this.clientId=clientId;
}
public String getClientId()
{
return this.clientId;
} 
public void setBytes(byte[] bytes)
{
this.bytes=bytes;
}
public byte[] getBytes()
{
return this.bytes;
}
}