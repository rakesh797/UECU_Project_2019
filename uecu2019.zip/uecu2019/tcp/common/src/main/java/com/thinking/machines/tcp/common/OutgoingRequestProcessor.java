package com.thinking.machines.tcp.common;
import com.thinking.machines.tcp.common.pojo.*;
import com.thinking.machines.common.pojo.*;
import com.thinking.machines.tcp.common.event.*;
import java.io.*;
import java.net.*;
import java.util.*;
public class OutgoingRequestProcessor implements Runnable
{
private OutputStream outputStream;
private InputStream inputStream;
private ProcessListener processListener;
private Thread thread;
private Client client;
private Socket socket;
private Queue<Pair<byte[],ResponseListener>> queue=new LinkedList<Pair<byte[],ResponseListener>>();
public OutgoingRequestProcessor(Socket socket,ProcessListener processListener,Client client,OutputStream outputStream,InputStream inputStream)
{
this.socket=socket;
this.processListener=processListener;
this.client=client;
this.inputStream=inputStream;
this.outputStream=outputStream;
}
public Client getClient()
{
return this.client;
}
public void start()
{
thread=new Thread(this);
thread.start();
}
public void add(byte[] data,ResponseListener responseListener)
{
queue.add(new Pair<byte[],ResponseListener>(data,responseListener));
thread.resume();
}
public void run()
{
ByteArrayOutputStream byteArrayOutputStream=new ByteArrayOutputStream();
byte[] header=new byte[10];
InputStream inputStream;
OutputStream outputStream;
int e,f,lengthOfDataBytes,byteCount,bytesRead,bytesSent,lengthOfResponseBytes,numberOfBytesToWrite,bufferSize;
byte responseBytes[],ack[];
byte temp[]=new byte[1024];
bufferSize=1024;
ack=new byte[1];
try
{
inputStream=socket.getInputStream();
outputStream=socket.getOutputStream();
while(true)
{
if(queue.isEmpty())
{
System.out.println("Thread is being suspended");
thread.suspend();
}
if(queue.size()==0) continue;
System.out.println("Got out of suspended mode and started working");
Pair<byte[],ResponseListener> pair;
pair=queue.remove();
byte[] data=pair.getFirst();
ResponseListener responseListener=pair.getSecond();
lengthOfDataBytes=data.length;
e=9;
f=lengthOfDataBytes;
while(e>=0)
{
header[e]=(byte)(f%10);
e--;
f=f/10;
}
outputStream.write(header,0,10);
outputStream.flush();
//send the dataBytes
inputStream.read(ack);
bytesSent=0;
ack[0]=0;
System.out.println("Header sent");
while(bytesSent<lengthOfDataBytes)
{
numberOfBytesToWrite=bufferSize;
if(bytesSent+bufferSize>lengthOfDataBytes)
{
numberOfBytesToWrite=lengthOfDataBytes-bytesSent;
}
outputStream.write(data,bytesSent,numberOfBytesToWrite);
outputStream.flush();
inputStream.read(ack);
bytesSent+=bufferSize;
}
System.out.println("Data sent");
// read bytes[] that contains length of response bytes
inputStream.read(header);
lengthOfResponseBytes=0;
e=9;
f=1;
while(e>0)
{
lengthOfResponseBytes+=f*header[e];
e--;
f=f*10;
}
ack[0]=1;
outputStream.write(ack,0,ack.length);
outputStream.flush();
System.out.println("Response header received");
// read response bytes
bytesRead=0;
byteCount=0;
while(true)
{
byteCount=inputStream.read(temp);
if(byteCount<0) break;
byteArrayOutputStream.write(temp,0,byteCount);// this may be wrong absolute may be
ack[0]=1;
outputStream.write(ack,0,ack.length);
outputStream.flush();
bytesRead+=byteCount;
if(bytesRead==lengthOfResponseBytes) break;
}
responseBytes=byteArrayOutputStream.toByteArray();
System.out.println("Response received");
responseListener.onResponse(responseBytes);
}// infiniteLoop
}catch(Exception exception)
{
exception.printStackTrace();
System.exit(0);
}
processListener.onCompleted(client);
}
}