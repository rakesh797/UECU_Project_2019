import com.thinking.machines.tcp.client.*;
import com.thinking.machines.tcp.common.pojo.*;
import com.thinking.machines.tcp.common.event.*;
import java.io.*;
public class TestClient implements TCPListener,ResponseListener
{
public byte[] onData(Client client,byte [] data)
{
String str=new String(data);
System.out.println(data);
return "INDORE".getBytes();
}
public void onOpen(Client client)
{
System.out.println("On open in client side");
}
public void onClose(Client client)
{
System.out.println("On closed on client side");
}
public static void main(String gg[]) throws IOException
{
TCPClient tcpClient=new TCPClient(5000,"localhost",6000,"localhost",TestClient);
tcpClient.send(gg[0].getBytes(),new ResponseListener(){
public void onResponse(byte bytes[])
{
String str=new String(bytes);
System.out.println("Response : "+bytes);
}
public void onError(String s)
{
System.out.println("Something went wrong");
}
});
}
}