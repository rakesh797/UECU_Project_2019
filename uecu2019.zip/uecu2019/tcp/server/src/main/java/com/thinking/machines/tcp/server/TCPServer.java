package com.thinking.machines.tcp.server;
import com.thinking.machines.common.pojo.*;
import com.thinking.machines.tcp.common.*;
import com.thinking.machines.tcp.common.event.*;
import com.thinking.machines.tcp.common.pojo.*;
import java.util.*;
import java.io.*;
import java.net.*;
public class TCPServer implements ProcessListener
{
private ServerSocket incomingRequestServerSocket;
private ServerSocket outgoingRequestServerSocket;
private int incomingRequestPortNumber;
private int outgoingRequestPortNumber;
private TCPListener tcpListener;
private Map<String,Pair<IncomingRequestProcessor,OutgoingRequestProcessor>> connections=new HashMap<>();
public TCPServer(int incomingRequestPortNumber,int outgoingRequestPortNumber)
{
this.incomingRequestPortNumber=incomingRequestPortNumber;
this.outgoingRequestPortNumber=outgoingRequestPortNumber;
this.incomingRequestServerSocket=null;
this.outgoingRequestServerSocket=null;
}
public void start(TCPListener tcpListener) throws IOException
{
this.tcpListener=tcpListener;
this.incomingRequestServerSocket=new ServerSocket(this.incomingRequestPortNumber);
this.outgoingRequestServerSocket=new ServerSocket(this.outgoingRequestPortNumber);
this.startAccepting();
}
private void startAccepting() throws IOException
{
Thread incomingRequestHandlerThread=new Thread(){
public void run()
{
System.out.println("Incoming request will be handled on :"+incomingRequestPortNumber);
try
{
Socket socket=incomingRequestServerSocket.accept();
Thread t=new Thread(){
public void run()
{
OutputStream outputStream;
InputStream inputStream;
byte ack[]=new byte[1];
byte header[]=new byte[10];
int i,j;
IncomingRequestProcessor incomingRequestProcessor;
OutgoingRequestProcessor outgoingRequestProcessor=null;
Client client;
String clientId=null;
try
{
clientId=java.util.UUID.randomUUID().toString();
client=new Client();
client.setClientId(clientId);
client.setClientIP(socket.getRemoteSocketAddress().toString());
inputStream=socket.getInputStream();
outputStream=socket.getOutputStream();
incomingRequestProcessor=new IncomingRequestProcessor(socket,TCPServer.this,TCPServer.this.tcpListener,client,inputStream,outputStream);
connections.put(clientId,new Pair<IncomingRequestProcessor,OutgoingRequestProcessor>(incomingRequestProcessor,outgoingRequestProcessor));
int k;
outputStream.write(clientId.getBytes());
outputStream.flush();
inputStream.read(ack);
}catch(Exception exception)
{
exception.printStackTrace(); // remove after testing
if(clientId!=null) connections.remove(clientId);
// do nothing
}
}
};
t.start();

}catch(Exception exception)
{
exception.printStackTrace();
System.exit(0);
}
}
};
incomingRequestHandlerThread.start();
Thread outgoingRequestHandlerThread=new Thread(){
public void run()
{
OutgoingRequestProcessor outgoingRequestProcessor;
System.out.println("Outgoing request will be handled form :"+outgoingRequestPortNumber);
try
{
while(true)
{
Socket socket=outgoingRequestServerSocket.accept();
Thread t=new Thread(){
public void run()
{
try
{
InputStream inputStream=socket.getInputStream();
OutputStream outputStream=socket.getOutputStream();
byte uuidBytes[]=new byte[1024];
int uuidSize=inputStream.read(uuidBytes);
byte ack[]=new byte[1];
ack[0]=100;
outputStream.write(ack);
outputStream.flush();
for(int k=uuidSize;k<1024;k++) uuidBytes[k]=32;
String uuid=new String(uuidBytes).trim();
Pair<IncomingRequestProcessor,OutgoingRequestProcessor> pair;
pair=connections.get(uuid);
if(pair==null)
{
socket.close();
return;
}
IncomingRequestProcessor incomingRequestProcessor=pair.getFirst();
OutgoingRequestProcessor outgoingRequestProcessor=new OutgoingRequestProcessor(socket,TCPServer.this,incomingRequestProcessor.getClient(),outputStream,inputStream);
pair.setSecond(outgoingRequestProcessor);
incomingRequestProcessor.start();
outgoingRequestProcessor.start();
tcpListener.onOpen(incomingRequestProcessor.getClient());
}catch(Exception exception)
{
exception.printStackTrace();
// something important is missing here
}
}
};
t.start();
}
}catch(Exception exception)
{
exception.printStackTrace();
System.exit(0);
}
}
};
outgoingRequestHandlerThread.start();
}
public void onCompleted(Client client)
{
// need to remove from map<String,Pair>
// need to notify the TCPListener [The Application]
}
public void send(Client client,byte bytes[],ResponseListener responseListener)
{
Pair<IncomingRequestProcessor,OutgoingRequestProcessor> pair;
pair=connections.get(client.getClientId());
if(pair==null)
{
responseListener.onError("Connection closed");
return;
}
OutgoingRequestProcessor outgoingRequestProcessor=pair.getSecond();
outgoingRequestProcessor.add(bytes,responseListener);
}
}