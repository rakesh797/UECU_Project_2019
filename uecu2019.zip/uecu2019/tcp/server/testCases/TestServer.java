import com.thinking.machines.tcp.server.*;
import com.thinking.machines.tcp.common.event.*;
import com.thinking.machines.tcp.common.pojo.*;
import java.util.*;
import java.io.*;
class TestTCPHandler implements TCPListener
{
public byte[] onData(Client client,byte []data)
{
String str=new String(data);
System.out.println("Request"+data);
return "UJJAIN".getBytes();
}
public void onOpen(Client client)
{
System.out.println("Client is being opened to connect");
}
public void onClose(Client client)
{
System.out.println("Client is being closed to connect");
}
}
class TestServer
{
public static void main(String gg[]) throws IOException
{
TCPServer tcpServer=new TCPServer(5000,6000);
try
{
tcpServer.start(new TestTCPHandler());
}catch(Exception exception)
{
exception.printStackTrace();
System.exit(0);
}
}
}