create table member
(
code bigint primary key auto_increment,
email_id char(100) unique,
username char(15) unique not null,
password char(100) not null,
password_key char(100) not null,
name char(25) not null,
contact_number char(15) unique
)engine=InnoDB;

create table member_friend
(
member_code bigint not null,
friend_member_code bigint not null,
primary key(member_code,friend_member_code)
)engine=InnoDB;

create table friend_request
(
from_member_code bigint,
to_member_code bigint,
date_of_request date not null,
time_of_request time not null,
primary key(from_member_code,to_member_code)
)engine=InnoDB;

create table offline_message
(
code bigint primary key auto_increment,
from_member_code bigint not null,
to_member_code bigint not null,
sending_date date not null,
sending_time time not null,
message varchar(5000) not null
)engine=InnoDB;