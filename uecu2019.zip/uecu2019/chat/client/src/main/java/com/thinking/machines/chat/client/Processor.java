package com.thinking.machines.chat.client;
import java.net.*;
import java.io.*;
public class Processor implements Runnable
{
private Socket socket;
private Thread thread;
Processor(Socket socket)
{
this.socket=socket;
}
public void start()
{
thread=new Thread(this);
thread.start();
}
public void run()
{
byte messageBytes[]=new byte[100];
InputStream inputStream;
try
{
inputStream=socket.getInputStream();
inputStream.read(messageBytes);
String message=new String(messageBytes);
System.out.println(message);
}catch(Exception exception)
{
System.out.println(exception);
}
}
}