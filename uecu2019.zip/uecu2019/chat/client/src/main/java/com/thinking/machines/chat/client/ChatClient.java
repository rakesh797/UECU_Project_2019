package com.thinking.machines.chat.client;
import java.net.*;
import java.io.*;
public class ChatClient
{
private ServerSocket serverSocket;
private int portNumber;
public ChatClient(int portNumber)
{
this.portNumber=portNumber;
this.serverSocket=null;
}
public void start() throws IOException
{
serverSocket=new ServerSocket(portNumber);
this.startAccepting();
}
public void startAccepting() throws IOException
{
Processor process;
Socket socket;
while(true)
{
socket=serverSocket.accept();
process=new Processor(socket);
process.start();
}
}
}