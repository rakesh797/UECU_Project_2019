import com.thinking.machines.chat.common.request.*;
import com.thinking.machines.chat.common.util.*;
import com.thinking.machines.chat.common.*;
import com.thinking.machines.tcp.client.*;
import com.thinking.machines.chat.client.*;
import java.util.*;
import java.io.*;
class tcp extends Thread
{
Thread thread;
byte[] message;
tcp(byte[] message)
{
this.message=message;
thread=new Thread();
start();
}
public void run()
{
try
{
TCPClient tcpClient=new TCPClient(5000,"localhost");
byte[] response=tcpClient.send(message,new ResponseListener(){
public void onResponse(byte bytes[])
{
String str=new String(bytes);
System.out.println(str);
}
});
}catch(Exception e)
{

}
}
}
class MessageTestCase extends Thread 
{
public static void main(String data[]) throws IOException
{

ChatClient chatClient=new ChatClient(5000);
System.out.println("Client Server si listening on Port 5000");
Login login=new Login();
login.setUsername("rakesh");
login.setPassword("patidar");
SendMessage sendMessage=new SendMessage();
sendMessage.setUsername(data[0]);
sendMessage.setMessage(data[2]);
sendMessage.setFriendUsername(data[1]);
String messageId=UUID.randomUUID().toString();
String loginPayLoad=ParseUtility.getJSONString(login);
String payLoad=ParseUtility.getJSONString(sendMessage);
Request request=new Request();
request.setMessageTypeId(Protocol.RequestMessageTypeId);
request.setMessageId(messageId);
request.setAction(com.thinking.machines.chat.common.Action.Login);
request.setPayLoad(loginPayLoad);
String requestMessage=ParseUtility.getRequestMessage(request);
System.out.println(requestMessage);
tcp t=new tcp(requestMessage.getBytes());
request.setAction(com.thinking.machines.chat.common.Action.SendMessage);
request.setPayLoad(payLoad);
requestMessage=ParseUtility.getRequestMessage(request);
System.out.println(requestMessage);
try
{
sleep(5000);
}catch(Exception e)
{
}
t=new tcp(requestMessage.getBytes());
System.out.println("Kaam pe lga diya h");
}

}