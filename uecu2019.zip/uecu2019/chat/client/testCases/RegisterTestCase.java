import com.thinking.machines.chat.common.request.*;
import com.thinking.machines.chat.common.util.*;
import com.thinking.machines.chat.common.*;
import com.thinking.machines.tcp.client.*;
import java.util.*;
import java.io.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
class RegisterFrame extends JFrame implements ActionListener
{
private Container container;
public static Button button;
private JTextField usernameTextField,codeTextField,emailIdTextField,mobileNumberTextField,passwordTextField,passwordKeyTextField,nameTextField;
private JLabel usernameLabel,codeLabel,emailIdLabel,mobileNumberLabel,passwordLabel,passwordKeyLabel,nameLabel;
private static Register register=new Register();

RegisterFrame()
{
initComponents();
setAppearance();
setListeners();
}
public void initComponents()
{
container=getContentPane();
container.setLayout(null);
usernameLabel=new JLabel("username :-");
codeLabel=new JLabel("code :-");
emailIdLabel=new JLabel("emailId :-");
mobileNumberLabel=new JLabel("mobile number :-");
passwordLabel=new JLabel("password :-");
passwordKeyLabel=new JLabel("password key :-");
nameLabel=new JLabel("name :-");

usernameTextField=new JTextField();
nameTextField=new JTextField();
codeTextField=new JTextField();
mobileNumberTextField=new JTextField();
passwordTextField=new JTextField();
passwordKeyTextField=new JTextField();
emailIdTextField=new JTextField();

button=new Button("Proceed");
usernameLabel.setBounds(50,50,100,20);
usernameTextField.setBounds(160,50,100,20); 

nameLabel.setBounds(50,70,100,20);
nameTextField.setBounds(160,70,100,20); 
emailIdLabel.setBounds(50,90,100,20);
emailIdTextField.setBounds(160,90,100,20); 
mobileNumberLabel.setBounds(50,110,100,20);
mobileNumberTextField.setBounds(160,110,100,20); 
passwordLabel.setBounds(50,130,100,20);
passwordTextField.setBounds(160,130,100,20); 
button.setBounds(180,180,50,25);

container.add(usernameLabel);
container.add(usernameTextField);
container.add(nameLabel);
container.add(nameTextField);
container.add(emailIdLabel);
container.add(emailIdTextField);
container.add(mobileNumberLabel);
container.add(mobileNumberTextField);
container.add(passwordLabel);
container.add(passwordTextField);
container.add(button);


setSize(400,500);
setLocation(300,200);
setVisible(true);
}
public void setListeners()
{
button.addActionListener(this);
}
public void setAppearance()
{

}
public void actionPerformed(ActionEvent ae)
{
if(ae.getSource()==button)
{
register.setUsername(usernameTextField.getText());
register.setName(nameTextField.getText());
register.setEmail(emailIdTextField.getText());
register.setContactNumber(mobileNumberTextField.getText());
register.setPassword(passwordTextField.getText());
button.setEnabled(false);
}
}
public Register getRegister()
{
return this.register;
}

}

class aaa
{
public static void main(String data[]) throws IOException
{
RegisterFrame rf=new RegisterFrame();
Register register=rf.getRegister();
String messageId=UUID.randomUUID().toString();
String payLoad=ParseUtility.getJSONString(register);
Request request=new Request();
request.setMessageTypeId(Protocol.RequestMessageTypeId);
request.setMessageId(messageId);
request.setAction(com.thinking.machines.chat.common.Action.Register);
request.setPayLoad(payLoad);
String requestMessage=ParseUtility.getRequestMessage(request);
System.out.println(requestMessage);

TCPClient tcpClient=new TCPClient(5000,"localhost");
//public byte[] send(byte []requestBytes,ResponseListener responseListener)
tcpClient.banana(requestMessage.getBytes(),new ResponseListener(){
public void onResponse(byte[] bytes)
{
}
});
byte[] response=tcpClient.send(requestMessage.getBytes(),new ResponseListener(){
public void onResponse(byte bytes[])
{
RegisterFrame.button.setEnabled(true);
}
});
System.out.println("Kaam pe lga diya h");
}


}