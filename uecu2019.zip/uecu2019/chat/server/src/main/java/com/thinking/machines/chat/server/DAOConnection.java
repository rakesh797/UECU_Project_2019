package com.thinking.machines.chat.server;
import java.sql.*;
public class DAOConnection
{
public static String driver;
public static String connectionString;
public static String username;
public static String password;
public static Connection getConnection()
{
try
{
Connection connection;
Class.forName(driver);
connection=DriverManager.getConnection(connectionString,username,password);
return connection;
}catch(Throwable throwable)
{
throwable.printStackTrace();
}
}
}