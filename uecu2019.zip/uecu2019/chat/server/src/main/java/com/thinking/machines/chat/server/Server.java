package com.thinking.machines.chat.server;
import java.text.*;
import java.util.*;
import java.io.*;
import com.google.gson.*;
import com.google.gson.stream.*;
import com.thinking.machines.tcp.server.event.*;
import com.thinking.machines.tcp.server.*;
import com.thinking.machines.chat.common.util.*;
import com.thinking.machines.chat.common.request.*;
import com.thinking.machines.chat.common.response.*;
import com.thinking.machines.chat.common.*;
import com.thinking.machines.chat.common.enums.*;
import com.thinking.machines.chat.server.util.*;
import com.thinking.machines.tcp.server.pojo.*;
import com.thinking.machines.logger.*;
import java.sql.*;
public class Server
{
public static HashMap<String,String> clients=new HashMap<>();
public static ArrayList<UserThread> onlineUsers=new ArrayList<>();
public static void addUser(String user,String IPAddress,int portNumber)
{
System.out.println("addUser k ander");
System.out.println("user: "+user);
System.out.println("ip"+IPAddress);
System.out.println("pn:"+portNumber);
clients.put(user,IPAddress);
UserThread userThread=new UserThread(IPAddress,portNumber,user);
onlineUsers.add(userThread);
userThread.start();
}
public static boolean sendMessage(String username,String message)
{
System.out.println(onlineUsers.size());
System.out.println("send Message Me:"+message);
for(UserThread user:onlineUsers)
{
System.out.println("Online users:"+user.getUsername());
if(user.getUsername().equals(username) && user.isActive())
{
System.out.println("user mil gaya ");
user.dispatch(message);
return true;
}
}
return false;
}
}