package com.thinking.machines.chat.server;
import java.io.*;
import java.sql.*;
public class GetConnection
{
public static Connection getConnection()
{
try
{
Connection c=null;
Class.forName("com.mysql.jdbc.Driver");
c=DriverManager.getConnection("jdbc:mysql://localhost:3306/chatdb","chatuser","chatuser");
return c;
}catch(Exception exception)
{
System.out.println(exception);
return null;
}
}
}