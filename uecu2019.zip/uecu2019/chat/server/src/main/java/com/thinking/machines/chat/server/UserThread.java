package com.thinking.machines.chat.server;
import java.util.*;
import java.io.*;
import java.net.*;
public class UserThread extends Thread
{
public Vector<Object> queue;
private String username;
private String IPAddress;
private int portNumber;
private boolean isActive;
public Thread thread;
public UserThread(String IPAddress,int portNumber,String username)
{
this.IPAddress=IPAddress;
this.portNumber=portNumber;
this.isActive=true;
queue=new Vector<Object>();
}

public String getUsername()
{
return this.username;
}
public String getIPAddress()
{
return this.IPAddress;
}
public int getPortNumber()
{
return this.portNumber;
}
public boolean isActive()
{
return this.isActive;
}
public void dispatch(Object object)
{
if(object!=null && isActive)
{
System.out.println("queue me chad gayi:"+object);
queue.addElement(object);
this.resume();
}
}
public Vector<Object> getUndispatchedObjects()
{
if(isActive==false) return this.queue;
return new Vector<Object>();
}

public void run()
{
try{
Object object;
while(true)
{
if(queue.size()==0) this.suspend();

//send the request
object=queue.get(0);
byte bytes[]=String.valueOf(object).getBytes();
Socket socket=new Socket(IPAddress,portNumber);
OutputStream outputStream=socket.getOutputStream();
outputStream.write(bytes,0,bytes.length);
outputStream.flush();

socket.close();
}

}
catch(Exception exception)
{
this.isActive=false;
}
}
}