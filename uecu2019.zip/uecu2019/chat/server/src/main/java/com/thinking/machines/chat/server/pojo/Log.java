package com.thinking.machines.chat.server.pojo;
public class Log
{
public String remoteAddress;
public String requestString;
public String requestTimeString;
public String responseTimeString;
public String responseString;
public void setRemoteAddress(String remoteAddress)
{
this.remoteAddress=remoteAddress;
} 
public String getRemoteAddress()
{
return this.remoteAddress;
}
public void setRequestString(String requestString)
{
this.requestString=requestString;
}
public String getRequestString()
{
return this.requestString;
}
public void setRequestTimeString(String requestTimeString)
{
this.requestTimeString=requestTimeString;
}
public String getRequestTimeString()
{
return this.requestTimeString;
}
public void setResponseString(String responseString)
{
this.responseString=responseString;
}
public String getResponseString()
{
return this.responseString;
}
public void setResponseTimeString(String responseTimeString)
{
this.responseTimeString=responseTimeString;
}
public String getResponseTimeString()
{
return this.responseTimeString;
}

}