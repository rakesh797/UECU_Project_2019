package com.thinking.machines.chat.server.util;
public class Configuration
{
private int chatServerPortNumber;
private String driver;
private String databaseConnectionString;
private String databaseUsername;
private String databasePassword;
private boolean logStore;
private boolean debugMode;
public int getChatServerPortNumber()
{
return this.chatServerPortNumber;
}
public String getDriver()
{
return this.driver;
}
public String getDatabaseConnectionString()
{
return this.databaseConnectionString;
}
public String getDatabaseUsername()
{
return this.databaseUsername;
}
public String getDatabasePassword()
{
return this.databasePassword;
}
public boolean getLogStore()
{
return this.logStore;
}
public boolean getDebugMode()
{
return this.debugMode;
}
}