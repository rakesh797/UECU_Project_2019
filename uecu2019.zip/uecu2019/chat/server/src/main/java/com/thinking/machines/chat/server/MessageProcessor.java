package com.thinking.machines.chat.server;
import java.sql.*;
import com.thinking.machines.chat.server.util.*;
import com.thinking.machines.chat.common.*;
import com.thinking.machines.chat.common.util.*;
import com.thinking.machines.chat.common.request.*;
import com.thinking.machines.chat.common.response.*;
import com.thinking.machines.chat.common.enums.*;
import java.util.*;
public class MessageProcessor
{
public static String process(String requestMessage,String IPAddress,int portNumber) throws SQLException
{
Request request=ParseUtility.getRequest(requestMessage);
int messageTypeId=request.getMessageTypeId();

String messageId=request.getMessageId();
String action=request.getAction();
String payLoad=request.getPayLoad();
System.out.println(action);
//System.out.println(action.equals(Action.Register));
if(action.equals(Action.Login))
{
LoginResponse loginResponse;
Response response;
Login login=ParseUtility.getObjectFromJSON(payLoad,Login.class);
String username=login.getUsername();
String password=login.getPassword();
//check in database if exists or not 
Server.addUser(username,IPAddress,portNumber);
response=new Response();
response.setMessageTypeId(Protocol.ResponseMessageTypeId);
response.setMessageId(messageId);
loginResponse=new LoginResponse();
loginResponse.setStatus(LoginResponseStatus.Successful);
loginResponse.setReason("");
payLoad=ParseUtility.getJSONString(loginResponse);
response.setPayLoad(payLoad);
String responseMessage=ParseUtility.getResponseMessage(response);
return responseMessage;

}

if(action.equals(Action.SendMessage))
{
System.out.println("Message k ander");
SendMessageResponse sendMessageResponse;
Response response;
SendMessage sendMessage=ParseUtility.getObjectFromJSON(payLoad,SendMessage.class);
String username=sendMessage.getUsername();
String friendUsername=sendMessage.getFriendUsername();
String message=sendMessage.getMessage();
System.out.println(friendUsername);
Server.sendMessage(friendUsername,message);
System.out.println("message server k pas pahoch gaya");
response=new Response();
response.setMessageTypeId(Protocol.ResponseMessageTypeId);
response.setMessageId(messageId);
sendMessageResponse=new SendMessageResponse();
sendMessageResponse.setStatus(SendMessageResponseStatus.Dispatched);
sendMessageResponse.setReason("");
payLoad=ParseUtility.getJSONString(sendMessageResponse);
response.setPayLoad(payLoad);
String responseMessage=ParseUtility.getResponseMessage(response);
return responseMessage;

//sent response not accepted and reasone that username already exist;

}
if(action.equals(Action.Register))
{
try
{
Connection connection=GetConnection.getConnection();
connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/chatdb","chatuser","chatuser");
RegisterResponse registerResponse;
Response response;
Register register=ParseUtility.getObjectFromJSON(payLoad,Register.class);
String username=register.getUsername();
String email=register.getEmail();
String contactNumber=register.getContactNumber();
String passwordKey=UUID.randomUUID().toString();
String password=Encryptor.encrypt(passwordKey,register.getPassword());
PreparedStatement prepareStatement=connection.prepareStatement("select code from member where username=?");
prepareStatement.setString(1,username);
ResultSet resultSet=prepareStatement.executeQuery();
if(resultSet.next())
{
resultSet.close();
prepareStatement.close();
response=new Response();
response.setMessageTypeId(Protocol.ResponseMessageTypeId);
response.setMessageId(messageId);
registerResponse=new RegisterResponse();
registerResponse.setStatus(RegisterResponseStatus.Rejected);
registerResponse.setReason("Username :"+ username+" already exist");
payLoad=ParseUtility.getJSONString(registerResponse);
response.setPayLoad(payLoad);
String responseMessage=ParseUtility.getResponseMessage(response);
return responseMessage;

//sent response not accepted and reasone that username already exist;
}
System.out.println("if k sabse uper");
prepareStatement=connection.prepareStatement("select code from member where email_id=?");
prepareStatement.setString(1,email);
resultSet=prepareStatement.executeQuery();
if(resultSet.next())
{
System.out.println("if k ander ");
registerResponse=new RegisterResponse();
response=new Response();
registerResponse.setStatus(RegisterResponseStatus.Rejected);
registerResponse.setReason("Email :"+ email+" already exist");
payLoad=ParseUtility.getJSONString(registerResponse);
response.setMessageTypeId(Protocol.ResponseMessageTypeId);
response.setMessageId(messageId);
response.setPayLoad(payLoad);
resultSet.close();
prepareStatement.close();
return ParseUtility.getResponseMessage(response);
//sent response String not accepted and reason that email is already exist.";
}
prepareStatement=connection.prepareStatement("select code from member where mobile_number=?");
prepareStatement.setString(1,contactNumber);
resultSet=prepareStatement.executeQuery();
if(resultSet.next())
{
resultSet.close();
prepareStatement.close();
registerResponse=new RegisterResponse();
response=new Response();
registerResponse.setStatus(RegisterResponseStatus.Rejected);
registerResponse.setReason("Contact Number :"+ contactNumber +" already exist");
payLoad=ParseUtility.getJSONString(registerResponse);
response.setMessageTypeId(Protocol.ResponseMessageTypeId);
response.setMessageId(messageId);
response.setPayLoad(payLoad);
return ParseUtility.getResponseMessage(response);
// set reponse String not accepted and reason that contactNumber already present
}
prepareStatement=connection.prepareStatement("insert into member (username,name,email_id,mobile_number,password,password_key) value (?,?,?,?,?,?)");
prepareStatement.setString(1,username);
prepareStatement.setString(2,register.getName());
prepareStatement.setString(3,email);
prepareStatement.setString(4,contactNumber);
prepareStatement.setString(5,password);
prepareStatement.setString(6,passwordKey);
prepareStatement.executeUpdate();
prepareStatement.close();
resultSet.close();
connection.close();
registerResponse=new RegisterResponse();
registerResponse.setStatus(RegisterResponseStatus.Accepted);
registerResponse.setReason("");
payLoad=ParseUtility.getJSONString(registerResponse);
response=new Response();
response.setMessageTypeId(Protocol.ResponseMessageTypeId);
response.setMessageId(messageId);
response.setPayLoad(payLoad);
return ParseUtility.getResponseMessage(response);
}catch(SQLException sqlException)
{
System.out.println("Connection lost "+sqlException);
}
catch(Exception exception)
{
System.out.println(exception);
}
}
//more condition for other protocols
return "";
}
}