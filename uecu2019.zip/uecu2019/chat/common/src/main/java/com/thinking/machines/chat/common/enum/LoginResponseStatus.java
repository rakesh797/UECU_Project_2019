package com.thinking.machines.chat.common.enums;
public class LoginResponseStatus
{
public static final String Successful="Successful";
public static final String Unsuccessful="Unsuccessful";
private static java.util.Set loginResponseStatusValues=new java.util.HashSet<>();
static
{
loginResponseStatusValues.add(Successful);
loginResponseStatusValues.add(Unsuccessful);
}
public static boolean isValid(String loginResponseStatus)
{
return loginResponseStatusValues.contains(loginResponseStatus);
}
}