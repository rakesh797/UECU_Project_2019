package com.thinking.machines.chat.common.response;
public class Response
{
private int messageTypeId;
private String messageId;
private String payLoad;
public Response()
{
this.messageTypeId=0;
this.messageId="";
this.payLoad="";
}
public void setMessageTypeId(int messageTypeId)
{
this.messageTypeId=messageTypeId;
}
public int getMessageTypeId()
{
return this.messageTypeId;
}
public void setMessageId(String messageId)
{
this.messageId=messageId;
}
public String getMessageId()
{
return this.messageId;
}
public void setPayLoad(String payLoad)
{
this.payLoad=payLoad;
}
public String getPayLoad()
{
return this.payLoad;
}
}