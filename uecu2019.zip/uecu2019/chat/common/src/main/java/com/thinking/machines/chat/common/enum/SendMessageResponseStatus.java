package com.thinking.machines.chat.common.enums;
public class SendMessageResponseStatus
{
public static final String Dispatched="Dispatched";
public static final String Undispatched="Undispatched";
private static java.util.Set sendMessageResponseStatusValues=new java.util.HashSet<>();
static
{
sendMessageResponseStatusValues.add(Dispatched);
sendMessageResponseStatusValues.add(Undispatched);
}
public static boolean isValid(String sendMessageResponseStatus)
{
return sendMessageResponseStatusValues.contains(sendMessageResponseStatus);
}
}