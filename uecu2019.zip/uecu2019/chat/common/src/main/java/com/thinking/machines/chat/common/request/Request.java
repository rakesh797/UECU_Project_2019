package com.thinking.machines.chat.common.request;
public class Request
{
private int messageTypeId;
private String messageId;
private String action;
private String payLoad;
public Request()
{
this.messageTypeId=0;
this.messageId="";
this.action="";
this.payLoad="";
}
public void setMessageTypeId(int messageTypeId)
{
this.messageTypeId=messageTypeId;
}
public int getMessageTypeId()
{
return this.messageTypeId;
}
public void setMessageId(String messageId)
{
this.messageId=messageId;
}
public String getMessageId()
{
return this.messageId;
}
public void setAction(String action)
{
this.action=action;
}
public String getAction()
{
return this.action;
}
public void setPayLoad(String payLoad)
{
this.payLoad=payLoad;
}
public String getPayLoad()
{
return this.payLoad;
}
}