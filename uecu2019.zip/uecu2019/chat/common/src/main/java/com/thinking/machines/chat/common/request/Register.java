package com.thinking.machines.chat.common.request;
import com.thinking.machines.chat.common.annotations.*;
public class Register implements java.io.Serializable
{
@Required
@MaxLength(value=25)
private String name;
@Optional
@MaxLength(value=100)
private String email;
@Optional
@MaxLength(value=15)
private String contactNumber;
@Required
@MaxLength(value=15)
private String username;
@Required
@MaxLength(value=15)
private String password;
public Register()
{
this.name="";
this.email="";
this.contactNumber="";
this.username="";
this.password="";
}
public void setName(String name)
{
this.name=name;
}
public String getName()
{
return this.name;
}
public void setEmail(String email)
{
this.email=email;
}
public String getEmail()
{
return this.email;
}
public void setContactNumber(String contactNumber)
{
this.contactNumber=contactNumber;
}
public String getContactNumber()
{
return this.contactNumber;
}
public void setUsername(String username)
{
this.username=username;
}
public String getUsername()
{
return this.username;
}
public void setPassword(String password)
{
this.password=password;
}
public String getPassword()
{
return this.password;
}
}