package com.thinking.machines.chat.common.response;
import com.thinking.machines.chat.common.annotations.*;
public class SendMessageResponse implements java.io.Serializable
{
@Required
@com.thinking.machines.chat.common.annotations.Enum(name="SendMessageResponseStatus")
private String status;
@Optional
@MaxLength(value=100)
private String reason;
public SendMessageResponse()
{
this.status="";
this.reason="";
}
public void setStatus(String status)
{
this.status=status;
}
public void setReason(String reason)
{
this.reason=reason;
}
public String getStatus()
{
return this.status;
}
public String getReason()
{
return this.reason;
}
}