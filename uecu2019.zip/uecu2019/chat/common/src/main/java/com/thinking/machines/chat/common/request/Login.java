package com.thinking.machines.chat.common.request;
import com.thinking.machines.chat.common.annotations.*;
public class Login implements java.io.Serializable
{
@Required
@MaxLength(value=15)
private String username;
@Required
@MaxLength(value=15)
private String password;
public Login()
{
this.username="";
this.password="";
}
public void setUsername(String username)
{
this.username=username;
}
public String getUsername()
{
return this.username;
}
public void setPassword(String password)
{
this.password=password;
}
public String getPassword()
{
return this.password;
}
}