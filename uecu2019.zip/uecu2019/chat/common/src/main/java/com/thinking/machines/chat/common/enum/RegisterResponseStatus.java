package com.thinking.machines.chat.common.enums;
public class RegisterResponseStatus
{
public static final String Accepted="Accepted";
public static final String Rejected="Rejected";
private static java.util.Set registerResponseStatusValues=new java.util.HashSet<>();
static
{
registerResponseStatusValues.add(Accepted);
registerResponseStatusValues.add(Rejected);
}
public static boolean isValid(String registerResponseStatus)
{
return registerResponseStatusValues.contains(registerResponseStatus);
}
}