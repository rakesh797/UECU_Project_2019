package com.thinking.machines.chat.common.request;
public class SendMessage
{
private String username;
private String message;
private String friendUsername;
public void setUsername(String username)
{
this.username=username;
}
public String getUsername()
{
return this.username;
}
public void setFriendUsername(String friendUsername)
{
this.friendUsername=friendUsername;
}
public String getFriendUsername()
{
return this.friendUsername;
}

public void setMessage(String message)
{
this.message=message;
}
public String getMessage()
{
return this.message;
}

}