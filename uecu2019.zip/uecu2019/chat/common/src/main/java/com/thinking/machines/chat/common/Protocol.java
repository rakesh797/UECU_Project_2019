package com.thinking.machines.chat.common;
public class Protocol
{
private Protocol()
{
//do nothing
}
public static final int RequestMessageTypeId=50;
public static final int ResponseMessageTypeId=51;
public static final int ErrorMessageTypeId=52;
public static final int InvalidMessageTypeId=-1;
public static boolean isValidMessageTypeId(int messageTypeId)
{
return messageTypeId==RequestMessageTypeId || messageTypeId==ResponseMessageTypeId ||
messageTypeId==ErrorMessageTypeId;
}
public static boolean isInvalidMessageTypeId(int messageTypeId)
{
return !isValidMessageTypeId(messageTypeId);
}
}