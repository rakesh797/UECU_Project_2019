package com.thinking.machines.utils;
import java.util.*;
import java.util.stream.*;

public class Process
{
public List<String> processIt(List<String> list)
{
//filter it
List<String> newList=list.stream().filter(s->{return (s.charAt(0)>=48 && s.charAt(0)<=57);}).collect(Collectors.toList());
return newList;

}
}