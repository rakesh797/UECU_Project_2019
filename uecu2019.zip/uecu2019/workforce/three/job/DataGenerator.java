import java.io.*;
import java.util.*;
public class DataGenerator
{
public static void main(String gg[])
{
try
{
File f=new File("data.txt");
if(f.exists()) f.delete();
RandomAccessFile raf=new RandomAccessFile(f,"rw");
long start=System.nanoTime();
for(int i=1;i<100000;++i)
{
raf.writeBytes(UUID.randomUUID().toString()+"\r\n");
}
raf.close();
long end=System.nanoTime();
System.out.println("Time taken : "+(end-start)/10000000+"ms");
}catch(Exception e)
{
e.printStackTrace();
}

}

}