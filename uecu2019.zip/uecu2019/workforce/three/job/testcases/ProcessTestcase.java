import com.thinking.machines.utils.*;
import java.io.*;
import java.util.*;
public class ProcessTestcase
{
public static void main(String gg[])
{
try
{
com.thinking.machines.utils.Process process=new com.thinking.machines.utils.Process();
File f=new File("..\\task\\data.txt");
if(!f.exists()) return;
List<String> list=new LinkedList<>();
RandomAccessFile raf=new RandomAccessFile(f,"rw");
for(int i=0; i<10; ++i)
{
String s=raf.readLine();
System.out.println(s);
list.add(s);
}
System.out.println(list.size());
List<String> newList=process.processIt(list);
for(String s:newList)
{
System.out.println(s);
}
}catch(Exception e)
{
e.printStackTrace();
}
}
}